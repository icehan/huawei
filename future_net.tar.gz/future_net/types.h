#ifndef __TYPES_H__
#define __TYPES_H__

#include <time.h>
#include <sys/timeb.h>
#define TOTAOL_SEC		10
#define TIME_FOR_SAVING 1500   // ms
#define INT_INF         999999999
#define INIT_LIST_WIDTH 350
#define MAX_LIST_WIDTH  1500

#define ESCAPE_TRAP_SRC
#define ESCAPE_TRAP_DST
#define ESCAPE_TRAP_INNER
#define DEBUG_ADJUST_L  


//#define DEBUG_LBD
//#define DEBUG_LBD_SIMPLE
//#define DEBUG_SF
#define DEBUG_SF_SIMPLE
#define DEBUG_ADJUST_SHOW

#endif
